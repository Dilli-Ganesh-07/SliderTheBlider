import gameState from '../unity/Assets/_Project/Scripts/Core/GameState.cs?raw';
import gameEvents from '../unity/Assets/_Project/Scripts/Core/GameEvents.cs?raw';
import eventBus from '../unity/Assets/_Project/Scripts/Core/EventBus.cs?raw';
import iGameSystem from '../unity/Assets/_Project/Scripts/Core/IGameSystem.cs?raw';
import gameSystemBehaviour from '../unity/Assets/_Project/Scripts/Core/GameSystemBehaviour.cs?raw';
import gameConfig from '../unity/Assets/_Project/Scripts/Core/GameConfig.cs?raw';
import gameManager from '../unity/Assets/_Project/Scripts/Core/GameManager.cs?raw';
import debugHud from '../unity/Assets/_Project/Scripts/Debug/GameDebugHUD.cs?raw';

export interface ScriptFile {
  name: string;
  path: string;
  purpose: string;
  code: string;
}

// Order = the order you should create them in Unity (dependencies first).
export const scripts: ScriptFile[] = [
  {
    name: 'GameState.cs',
    path: 'Assets/_Project/Scripts/Core/',
    purpose: 'Enums for the state machine (Boot, Menu, Playing, Paused, GameOver) and run end reasons.',
    code: gameState,
  },
  {
    name: 'GameEvents.cs',
    path: 'Assets/_Project/Scripts/Core/',
    purpose: 'Event payload structs (state changed, run started, run ended).',
    code: gameEvents,
  },
  {
    name: 'EventBus.cs',
    path: 'Assets/_Project/Scripts/Core/',
    purpose: 'Allocation-free generic publish/subscribe used for all cross-system messaging.',
    code: eventBus,
  },
  {
    name: 'IGameSystem.cs',
    path: 'Assets/_Project/Scripts/Core/',
    purpose: 'The hook contract every future phase implements to join the main loop.',
    code: iGameSystem,
  },
  {
    name: 'GameSystemBehaviour.cs',
    path: 'Assets/_Project/Scripts/Core/',
    purpose: 'MonoBehaviour base class that auto-registers with GameManager and offers empty virtual hooks.',
    code: gameSystemBehaviour,
  },
  {
    name: 'GameConfig.cs',
    path: 'Assets/_Project/Scripts/Core/',
    purpose: 'ScriptableObject with FPS, physics step, orientation and flow settings.',
    code: gameConfig,
  },
  {
    name: 'GameManager.cs',
    path: 'Assets/_Project/Scripts/Core/',
    purpose: 'The engine boot + state machine + main loop dispatcher. The heart of Phase 1.',
    code: gameManager,
  },
  {
    name: 'GameDebugHUD.cs',
    path: 'Assets/_Project/Scripts/Debug/',
    purpose: 'Temporary on-screen test panel that proves the loop works (deleted in Phase 10).',
    code: debugHud,
  },
];

export const folderTree = `Assets/
└── _Project/
    ├── Scenes/
    │   └── Main.unity                  (you create this - Step 5)
    ├── Settings/
    │   └── GameConfig.asset            (you create this - Step 6)
    ├── Scripts/
    │   ├── Core/
    │   │   ├── GameState.cs
    │   │   ├── GameEvents.cs
    │   │   ├── EventBus.cs
    │   │   ├── IGameSystem.cs
    │   │   ├── GameSystemBehaviour.cs
    │   │   ├── GameConfig.cs
    │   │   └── GameManager.cs
    │   └── Debug/
    │       └── GameDebugHUD.cs
    ├── Prefabs/                        (empty now - Phases 3, 6, 7, 9)
    ├── Materials/                      (empty now - Phases 2, 3, 6)
    └── Art/                            (empty now - optional)`;

export const hookMap: { phase: string; script: string; hook: string; order: string }[] = [
  { phase: '2 · Camera & Lighting', script: 'CameraRig', hook: 'LateTick()', order: '900' },
  { phase: '3 · Player Controller', script: 'PlayerController', hook: 'FixedTick(), OnRunReset()', order: '0' },
  { phase: '4 · Input & Lanes', script: 'InputService / LaneMover', hook: 'Tick()', order: '-100 / 5' },
  { phase: '5 · Jump & Stunts', script: 'PlayerJump', hook: 'FixedTick()', order: '10' },
  { phase: '6 · Track Generator', script: 'TrackGenerator', hook: 'OnRunStart(), Tick(), OnRunReset()', order: '100' },
  { phase: '7 · Obstacles & Pooling', script: 'ObstacleSpawner', hook: 'Tick(), OnRunReset()', order: '110' },
  { phase: '8 · Collisions & Crash', script: 'CrashHandler', hook: 'calls GameManager.EndRun(Crash), OnRunEnd()', order: '200' },
  { phase: '9 · Coins & Progression', script: 'ScoreSystem / CoinCollector', hook: 'Tick(), OnRunEnd()', order: '300' },
  { phase: '10 · UI & Game Over', script: 'UIController', hook: 'EventBus<GameStateChangedEvent>, EventBus<RunEndedEvent>', order: '1000' },
];
