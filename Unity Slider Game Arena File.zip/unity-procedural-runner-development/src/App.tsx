import { useState } from 'react';
import { scripts, folderTree, hookMap } from './phase1Data';

type Tab = 'overview' | 'steps' | 'scripts' | 'hooks' | 'test';

const tabs: { id: Tab; label: string }[] = [
  { id: 'overview', label: '1 · Overview & Folders' },
  { id: 'steps', label: '2 · Unity Setup Steps' },
  { id: 'scripts', label: '3 · Scripts (copy-paste)' },
  { id: 'hooks', label: '4 · Future Hook Map' },
  { id: 'test', label: '5 · Test & Troubleshoot' },
];

function CopyButton({ text }: { text: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      onClick={async () => {
        await navigator.clipboard.writeText(text);
        setDone(true);
        setTimeout(() => setDone(false), 1500);
      }}
      className="rounded-md bg-emerald-500 px-3 py-1 text-xs font-semibold text-slate-900 hover:bg-emerald-400"
    >
      {done ? 'Copied ✓' : 'Copy code'}
    </button>
  );
}

function Code({ children }: { children: string }) {
  return (
    <pre className="overflow-x-auto rounded-lg border border-slate-700 bg-slate-950 p-4 text-[12.5px] leading-relaxed text-slate-200">
      <code>{children}</code>
    </pre>
  );
}

function Step({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-xl border border-slate-700 bg-slate-800/60 p-5">
      <h3 className="mb-3 flex items-center gap-3 text-lg font-semibold text-white">
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-sm font-bold text-slate-900">
          {n}
        </span>
        {title}
      </h3>
      <div className="space-y-2 text-sm leading-relaxed text-slate-300">{children}</div>
    </section>
  );
}

const K = ({ children }: { children: React.ReactNode }) => (
  <code className="rounded bg-slate-900 px-1.5 py-0.5 text-emerald-300">{children}</code>
);

function Overview() {
  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-5 text-sm leading-relaxed text-slate-300">
        <h2 className="mb-2 text-xl font-bold text-white">What Phase 1 builds</h2>
        <p>
          A clean, testable <b>engine bootstrap and main loop</b>. After this phase you will have a{' '}
          <K>GameManager</K> that applies engine settings, runs a 5-state machine, and forwards{' '}
          <K>Update</K>, <K>FixedUpdate</K> and <K>LateUpdate</K> to any registered system, but only while the
          state is <K>Playing</K>. A debug panel proves it works. Nothing moves yet; that starts in Phase 3.
        </p>
        <ul className="mt-3 list-disc space-y-1 pl-5">
          <li>
            <b>State machine:</b> Boot → Menu → Playing ⇄ Paused → GameOver → (Retry or Menu)
          </li>
          <li>
            <b>Hook system:</b> <K>IGameSystem</K> / <K>GameSystemBehaviour</K>. Later phases inherit it and
            override only the callbacks they need.
          </li>
          <li>
            <b>EventBus:</b> type-safe, allocation-free messaging between systems and UI.
          </li>
          <li>
            <b>GameConfig:</b> a ScriptableObject for FPS, physics step, portrait lock and similar settings.
          </li>
          <li>
            <b>Note:</b> the blueprint is the Sled Surfers decompile. As you specified, we are building a
            3-lane procedural <i>runner</i> in its architectural style: the same EventBus, GameState and
            module-based design, with the states simplified for a runner.
          </li>
        </ul>
      </div>

      <div>
        <h3 className="mb-2 text-lg font-semibold text-white">Exact folder structure</h3>
        <Code>{folderTree}</Code>
      </div>

      <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-5 text-sm text-slate-300">
        <h3 className="mb-2 text-lg font-semibold text-white">Loop diagram (one frame)</h3>
        <Code>{`Unity Update()        ─► GameManager.Update()
                              if State == Playing:
                                RunTime += dt
                                foreach system (sorted by Order): system.Tick(dt)

Unity FixedUpdate()   ─► GameManager.FixedUpdate()
                              if State == Playing:
                                foreach system: system.FixedTick(fixedDt)

Unity LateUpdate()    ─► GameManager.LateUpdate()
                              if State == Playing:
                                foreach system: system.LateTick(dt)

Run lifecycle:
  StartRun()/Restart() ─► OnRunReset() ─► State=Playing ─► OnRunStart() ─► RunStartedEvent
  EndRun(reason)       ─► State=GameOver ─► OnRunEnd()  ─► RunEndedEvent
  PauseRun()/ResumeRun ─► Time.timeScale 0 / 1`}</Code>
      </div>
    </div>
  );
}

function Steps() {
  return (
    <div className="space-y-4">
      <Step n={1} title="Create the Unity project">
        <p>
          Open <b>Unity Hub → Projects → New project</b>. Make sure the editor version is{' '}
          <K>6000.3.15f1</K> (install it from Hub → Installs if it is missing; add the{' '}
          <b>Android Build Support</b> module with OpenJDK and SDK/NDK).
        </p>
        <p>
          Pick the template <b>Universal 3D</b> (URP). Name it <K>SliderRunner</K> and click{' '}
          <b>Create project</b>. Wait for the editor to open.
        </p>
      </Step>

      <Step n={2} title="Create the folder structure">
        <p>
          In the <b>Project</b> window (bottom), right-click <K>Assets</K> → <b>Create → Folder</b> and name it{' '}
          <K>_Project</K>. Inside it create: <K>Scenes</K>, <K>Settings</K>, <K>Scripts</K>, <K>Prefabs</K>,{' '}
          <K>Materials</K>, <K>Art</K>.
        </p>
        <p>
          Inside <K>Scripts</K> create two folders: <K>Core</K> and <K>Debug</K>.
        </p>
      </Step>

      <Step n={3} title="Create each script, in this order">
        <p>
          Open the <b>Scripts</b> tab on this page. For each of the 8 files, in the order listed:
        </p>
        <ol className="list-decimal space-y-1 pl-5">
          <li>
            In the Project window, right-click the correct folder (<K>Scripts/Core</K> or <K>Scripts/Debug</K>).
          </li>
          <li>
            Choose <b>Create → MonoBehaviour Script</b> (in Unity 6 it is under <b>Create → Scripting</b> in
            some layouts).
          </li>
          <li>
            Type the <b>exact file name</b> (for example <K>GameManager</K>) and press Enter. The file name
            must match the class name.
          </li>
          <li>
            Double-click it to open your IDE, press <b>Ctrl+A</b> and paste over the default content, then
            save.
          </li>
          <li>
            For the interface, enum, struct and static-class files (<K>GameState</K>, <K>GameEvents</K>,{' '}
            <K>EventBus</K>, <K>IGameSystem</K>), Unity still creates a MonoBehaviour template. Replace all of
            it with the pasted code. That is fine, as these files do not contain MonoBehaviours.
          </li>
        </ol>
        <p>
          Return to the Unity editor and wait for the spinner (bottom right) to finish compiling. The Console
          (<b>Window → General → Console</b>) must show <b>0 errors</b>.
        </p>
        <p className="text-amber-300">
          Shortcut: the project files are in the <K>unity/Assets/_Project</K> folder. If you can download the
          project, copy that folder into your Unity project's <K>Assets</K> folder instead of pasting.
        </p>
      </Step>

      <Step n={4} title="Create the GameConfig asset">
        <p>
          Right-click <K>Assets/_Project/Settings</K> → <b>Create → SliderRunner → Game Config</b>. Name it{' '}
          <K>GameConfig</K>.
        </p>
        <p>
          Click it and check the Inspector. The defaults are <b>Target Frame Rate 60</b>, <b>VSync off</b>,{' '}
          <b>Fixed Delta Time 0.01667</b>, <b>Lock Portrait on</b> and <b>Auto Start Run off</b>. Leave these
          for now.
        </p>
      </Step>

      <Step n={5} title="Create and save the Main scene">
        <p>
          <b>File → New Scene → Basic (Built-in/URP)</b> → <b>Create</b>. Then <b>File → Save As…</b> →{' '}
          <K>Assets/_Project/Scenes/Main.unity</K>.
        </p>
        <p>
          Open <b>File → Build Profiles</b>, select your platform, click <b>Open Scene List → Add Open
          Scenes</b>. <K>Main</K> must be ticked at index 0.
        </p>
      </Step>

      <Step n={6} title="Add the GameManager to the scene">
        <ol className="list-decimal space-y-1 pl-5">
          <li>
            In the <b>Hierarchy</b>, right-click → <b>Create Empty</b>. Rename it <K>[Systems]</K>.
          </li>
          <li>
            In the Inspector, click the <b>⋮</b> next to Transform → <b>Reset</b> (position 0,0,0).
          </li>
          <li>
            Click <b>Add Component</b>, type <K>GameManager</K> and press Enter.
          </li>
          <li>
            Drag <K>GameConfig</K> from the Project window into the <b>Config</b> slot of the GameManager.
          </li>
        </ol>
      </Step>

      <Step n={7} title="Add the debug HUD">
        <ol className="list-decimal space-y-1 pl-5">
          <li>
            Right-click <K>[Systems]</K> in the Hierarchy → <b>Create Empty</b> to make a child. Rename it{' '}
            <K>DebugHUD</K>.
          </li>
          <li>
            <b>Add Component → GameDebugHUD</b>. Leave <b>Visible</b> ticked.
          </li>
        </ol>
        <p>
          Your Hierarchy should now be: <K>SampleScene/Main</K> → Main Camera, Directional Light,{' '}
          <K>[Systems]</K> → <K>DebugHUD</K>.
        </p>
      </Step>

      <Step n={8} title="Player Settings (portrait + Android, matches the blueprint)">
        <p>
          <b>Edit → Project Settings → Player</b> → <b>Resolution and Presentation</b> → <b>Default Orientation:
          Portrait</b>.
        </p>
        <p>
          <b>Other Settings</b> (Android tab): <b>Scripting Backend: IL2CPP</b>, <b>Target Architectures:
          ARM64</b>, <b>Minimum API Level: 25</b>. These match the blueprint and can be set now or later.
        </p>
        <p>
          Optional: <b>File → Build Profiles → Android → Switch Platform</b>. You can keep working in the editor
          on any platform, as nothing in Phase 1 is platform-specific.
        </p>
      </Step>

      <Step n={9} title="Press Play and run the tests">
        <p>
          Press the <b>▶ Play</b> button, then go to the <b>Test & Troubleshoot</b> tab and tick through the
          checklist.
        </p>
      </Step>
    </div>
  );
}

function Scripts() {
  const [i, setI] = useState(0);
  const s = scripts[i];
  return (
    <div className="grid gap-4 lg:grid-cols-[260px_1fr]">
      <nav className="space-y-1">
        {scripts.map((f, idx) => (
          <button
            key={f.name}
            onClick={() => setI(idx)}
            className={`w-full rounded-lg border px-3 py-2 text-left text-sm transition ${
              idx === i
                ? 'border-emerald-400 bg-emerald-500/10 text-white'
                : 'border-slate-700 bg-slate-800/60 text-slate-300 hover:border-slate-500'
            }`}
          >
            <span className="mr-2 text-xs text-slate-500">{idx + 1}.</span>
            {f.name}
          </button>
        ))}
      </nav>
      <div className="min-w-0 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-lg font-semibold text-white">{s.name}</h3>
            <p className="text-xs text-slate-400">
              Folder: <K>{s.path}</K>
            </p>
          </div>
          <CopyButton text={s.code} />
        </div>
        <p className="text-sm text-slate-300">{s.purpose}</p>
        <div className="max-h-[70vh] overflow-auto rounded-lg">
          <Code>{s.code}</Code>
        </div>
      </div>
    </div>
  );
}

function Hooks() {
  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-5 text-sm leading-relaxed text-slate-300">
        <h2 className="mb-2 text-xl font-bold text-white">How later phases attach to the loop</h2>
        <p>
          Every future script inherits <K>GameSystemBehaviour</K>, overrides <K>Order</K> and just the callbacks it
          needs. It is <b>auto-registered</b> with <K>GameManager</K>. You never edit <K>GameManager</K> again,
          except to add config values to <K>GameConfig</K>. The same hooks are marked with{' '}
          <K>// PHASE n</K> comments inside <K>GameManager.cs</K>.
        </p>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-700">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-800 text-slate-300">
            <tr>
              <th className="p-3">Phase</th>
              <th className="p-3">Script (future)</th>
              <th className="p-3">Hook it uses</th>
              <th className="p-3">Order</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700 text-slate-300">
            {hookMap.map((h) => (
              <tr key={h.phase} className="bg-slate-900/40">
                <td className="p-3 font-medium text-white">{h.phase}</td>
                <td className="p-3">
                  <K>{h.script}</K>
                </td>
                <td className="p-3">{h.hook}</td>
                <td className="p-3">{h.order}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>
        <h3 className="mb-2 text-lg font-semibold text-white">Template you will reuse every phase</h3>
        <Code>{`using SliderRunner.Core;
using UnityEngine;

public class PlayerController : GameSystemBehaviour   // auto-registers with GameManager
{
    public override int Order => 0;                   // execution priority

    public override void OnRunReset() { /* teleport to start, zero velocity */ }
    public override void OnRunStart() { /* unfreeze */ }
    public override void FixedTick(float dt) { /* physics-step movement */ }
    public override void OnRunEnd()   { /* stop / crash anim */ }
}

// Ending a run from anywhere (Phase 8):
//     GameManager.Instance.EndRun(RunEndReason.Crash);
// Listening from anywhere (Phase 10):
//     EventBus<RunEndedEvent>.Subscribe(e => ShowGameOver(e.RunDuration));`}</Code>
      </div>
    </div>
  );
}

const checks: { t: string; expect: string }[] = [
  { t: 'Press Play. Check the Console.', expect: '"[GameState] Boot -> Menu" appears one frame after start. No red errors.' },
  { t: 'Look at the Game view (top-left).', expect: 'The panel shows State: Menu, FPS near 60, and a "Start Run" button.' },
  { t: 'Click Start Run.', expect: 'Console: "Menu -> Playing" and "[Run] Started #1". Run Time counts up.' },
  { t: 'Watch Tick / FixedTick / LateTick.', expect: 'All three counters rise while Playing. FixedTick rises at about 60 per second.' },
  { t: 'Click Pause.', expect: 'State: Paused. Run Time and all counters freeze. FPS still updates.' },
  { t: 'Click Resume.', expect: 'State: Playing. Counters continue from where they stopped.' },
  { t: 'Click Simulate Crash.', expect: 'Console: "Playing -> GameOver" and "[Run] Ended (Crash) after X.XXs". Counters freeze.' },
  { t: 'Click Retry.', expect: 'Counters reset to 0, "[Run] Started #2" appears, and Run # shows 2.' },
  { t: 'Click Restart while Playing, then Pause → Main Menu.', expect: 'State returns to Menu with Run Time 0.' },
  { t: 'Tick "Auto Start Run" in GameConfig and press Play.', expect: 'The run starts by itself right after boot. Untick it afterwards.' },
];

function Test() {
  const [done, setDone] = useState<Record<number, boolean>>({});
  const count = Object.values(done).filter(Boolean).length;
  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-5">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">Phase 1 acceptance checklist</h2>
          <span className="rounded-full bg-emerald-500 px-3 py-1 text-xs font-bold text-slate-900">
            {count} / {checks.length}
          </span>
        </div>
        <ul className="space-y-2">
          {checks.map((c, idx) => (
            <li key={idx}>
              <label className="flex cursor-pointer gap-3 rounded-lg border border-slate-700 bg-slate-900/50 p-3 text-sm">
                <input
                  type="checkbox"
                  className="mt-1 h-4 w-4 accent-emerald-500"
                  checked={!!done[idx]}
                  onChange={(e) => setDone({ ...done, [idx]: e.target.checked })}
                />
                <span>
                  <b className="text-white">{c.t}</b>
                  <br />
                  <span className="text-slate-400">Expected: {c.expect}</span>
                </span>
              </label>
            </li>
          ))}
        </ul>
        {count === checks.length && (
          <p className="mt-4 rounded-lg bg-emerald-500/15 p-3 text-sm text-emerald-300">
            Phase 1 is complete. Reply "Begin Phase 2" to continue with Camera Setup & Lighting.
          </p>
        )}
      </div>

      <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-5 text-sm text-slate-300">
        <h3 className="mb-3 text-lg font-semibold text-white">Troubleshooting</h3>
        <ul className="space-y-3">
          <li>
            <b className="text-white">"The type or namespace 'SliderRunner' could not be found".</b> A file was
            pasted into the wrong place, or one of the 8 scripts is missing. Check that all files from the
            folder tree exist and the Console shows no earlier error.
          </li>
          <li>
            <b className="text-white">"Script class cannot be found" or "No MonoBehaviour scripts in the file".</b>{' '}
            The file name doesn't exactly match the class name (<K>GameManager.cs</K> must contain{' '}
            <K>class GameManager</K>). Rename the file.
          </li>
          <li>
            <b className="text-white">Add Component can't find GameDebugHUD.</b> It lives in namespace{' '}
            <K>SliderRunner.DebugTools</K>. Search for it by its class name, and make sure the Console has no
            compile errors, because Unity only lists scripts that compile.
          </li>
          <li>
            <b className="text-white">Nothing happens and the HUD is missing.</b> The HUD only draws once{' '}
            <K>GameManager.Instance</K> exists. Check that <K>[Systems]</K> is active and has the GameManager.
          </li>
          <li>
            <b className="text-white">"Duplicate instance destroyed".</b> There are two GameManagers in the
            scene. Delete one.
          </li>
          <li>
            <b className="text-white">Game stays frozen after stopping Play.</b> This can't normally happen,
            as <K>OnDestroy</K> resets <K>Time.timeScale</K>. If it does, set Time.timeScale to 1 in{' '}
            <b>Edit → Project Settings → Time</b>.
          </li>
          <li>
            <b className="text-white">FPS is capped at 60 in the Editor.</b> That is expected. It matches the
            target setting. On Android, VSync must be off, which the config does.
          </li>
          <li>
            <b className="text-white">Console warning: "No GameConfig assigned".</b> Drag the GameConfig asset
            into the GameManager's Config slot (Step 6).
          </li>
        </ul>
      </div>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState<Tab>('overview');
  return (
    <div className="min-h-screen bg-slate-900 text-slate-200">
      <header className="border-b border-slate-800 bg-slate-950">
        <div className="mx-auto max-w-6xl px-4 py-5">
          <p className="text-xs font-semibold uppercase tracking-widest text-emerald-400">
            Unity 6000.3.15f1 · Phase 1 of 10
          </p>
          <h1 className="text-2xl font-extrabold text-white sm:text-3xl">
            Engine Initialization & Main Game Loop
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Complete code, folder structure, setup steps and the hook map for future phases.
          </p>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 py-6">
        <div className="mb-6 flex flex-wrap gap-2">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`rounded-lg px-4 py-2 text-sm font-semibold transition ${
                tab === t.id
                  ? 'bg-emerald-500 text-slate-900'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {tab === 'overview' && <Overview />}
        {tab === 'steps' && <Steps />}
        {tab === 'scripts' && <Scripts />}
        {tab === 'hooks' && <Hooks />}
        {tab === 'test' && <Test />}
      </div>
    </div>
  );
}
