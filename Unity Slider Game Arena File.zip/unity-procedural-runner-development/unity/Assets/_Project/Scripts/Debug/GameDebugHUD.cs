// ============================================================================
//  GameDebugHUD.cs
//  Location : Assets/_Project/Scripts/Debug/GameDebugHUD.cs
//  Phase    : 1  (temporary - replaced by real UI in PHASE 10)
//
//  A throw-away on-screen panel that PROVES the Phase 1 loop works:
//    - shows the current GameState, run time and FPS
//    - shows how many Tick / FixedTick / LateTick calls were received this run
//      (they must only grow while the state is Playing)
//    - gives Start / Pause / Resume / Crash / Restart / Menu buttons
//
//  It also doubles as the reference example of a minimal IGameSystem.
//  Uses OnGUI (IMGUI) so it needs NO Canvas, NO Input System setup and NO assets.
//  You can delete this file safely after Phase 10.
// ============================================================================

using SliderRunner.Core;
using UnityEngine;

namespace SliderRunner.DebugTools
{
    public sealed class GameDebugHUD : GameSystemBehaviour
    {
        [SerializeField] private bool visible = true;

        // Late order => runs after every gameplay system.
        public override int Order => 1000;

        private int _ticks;
        private int _fixedTicks;
        private int _lateTicks;
        private float _fps;

        // ---------------- IGameSystem hooks (counting calls) ----------------
        public override void OnRunReset()
        {
            _ticks = _fixedTicks = _lateTicks = 0;
        }

        public override void Tick(float deltaTime)            { _ticks++; }
        public override void FixedTick(float fixedDeltaTime)  { _fixedTicks++; }
        public override void LateTick(float deltaTime)        { _lateTicks++; }

        // ---------------- Event logging (demonstrates EventBus) -------------
        protected override void OnEnable()
        {
            base.OnEnable(); // keep auto-registration with GameManager
            EventBus<GameStateChangedEvent>.Subscribe(OnStateChanged);
            EventBus<RunStartedEvent>.Subscribe(OnRunStarted);
            EventBus<RunEndedEvent>.Subscribe(OnRunEnded);
        }

        protected override void OnDisable()
        {
            EventBus<GameStateChangedEvent>.Unsubscribe(OnStateChanged);
            EventBus<RunStartedEvent>.Unsubscribe(OnRunStarted);
            EventBus<RunEndedEvent>.Unsubscribe(OnRunEnded);
            base.OnDisable();
        }

        private static void OnStateChanged(GameStateChangedEvent e)
            => UnityEngine.Debug.Log($"[GameState] {e.Previous} -> {e.Current}");

        private static void OnRunStarted(RunStartedEvent e)
            => UnityEngine.Debug.Log($"[Run] Started #{e.RunNumber}");

        private static void OnRunEnded(RunEndedEvent e)
            => UnityEngine.Debug.Log($"[Run] Ended ({e.Reason}) after {e.RunDuration:F2}s");

        // ---------------- FPS (uses unscaled time so it works while paused) --
        private void Update()
        {
            float instant = 1f / Mathf.Max(Time.unscaledDeltaTime, 0.0001f);
            _fps = Mathf.Lerp(_fps, instant, 0.1f);
        }

        // ---------------- Drawing -------------------------------------------
        private void OnGUI()
        {
            if (!visible) return;

            var gm = GameManager.Instance;
            if (gm == null) return;

            // Scale IMGUI so it is readable on a phone screen.
            float scale = Mathf.Max(1f, Screen.height / 720f);
            GUI.matrix = Matrix4x4.Scale(new Vector3(scale, scale, 1f));

            GUILayout.BeginArea(new Rect(12, 12, 300, 460), GUI.skin.box);

            GUILayout.Label($"<b>State:</b> {gm.State}");
            GUILayout.Label($"Run #{gm.RunCount}   Time: {gm.RunTime:F1}s");
            GUILayout.Label($"FPS: {_fps:F0} (target {Application.targetFrameRate})");
            GUILayout.Label($"Tick: {_ticks}   FixedTick: {_fixedTicks}   LateTick: {_lateTicks}");
            GUILayout.Space(6);

            switch (gm.State)
            {
                case GameState.Menu:
                    if (GUILayout.Button("Start Run", GUILayout.Height(36))) gm.StartRun();
                    break;

                case GameState.Playing:
                    if (GUILayout.Button("Pause", GUILayout.Height(36))) gm.PauseRun();
                    if (GUILayout.Button("Simulate Crash", GUILayout.Height(36))) gm.EndRun(RunEndReason.Crash);
                    if (GUILayout.Button("Restart", GUILayout.Height(36))) gm.Restart();
                    break;

                case GameState.Paused:
                    if (GUILayout.Button("Resume", GUILayout.Height(36))) gm.ResumeRun();
                    if (GUILayout.Button("Main Menu", GUILayout.Height(36))) gm.ReturnToMenu();
                    break;

                case GameState.GameOver:
                    if (GUILayout.Button("Retry", GUILayout.Height(36))) gm.Restart();
                    if (GUILayout.Button("Main Menu", GUILayout.Height(36))) gm.ReturnToMenu();
                    break;
            }

            GUILayout.EndArea();
        }
    }
}
