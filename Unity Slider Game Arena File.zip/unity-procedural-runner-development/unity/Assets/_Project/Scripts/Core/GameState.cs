// ============================================================================
//  GameState.cs
//  Location : Assets/_Project/Scripts/Core/GameState.cs
//  Phase    : 1 (Engine Initialization & Main Game Loop)
//
//  The single source of truth for "what is the game doing right now?".
//  Every later phase reads this (via GameManager.State) to decide whether it
//  should be ticking, frozen, or reset.
// ============================================================================

namespace SliderRunner.Core
{
    public enum GameState
    {
        /// <summary>Engine just started; GameManager is still booting (1 frame).</summary>
        Boot = 0,

        /// <summary>Main menu / waiting for the player to tap "Play".
        /// PHASE 10 hooks the Main Menu UI panel here.</summary>
        Menu = 1,

        /// <summary>Run in progress. ONLY in this state do systems receive Tick/FixedTick/LateTick.</summary>
        Playing = 2,

        /// <summary>Run frozen (Time.timeScale = 0). PHASE 10 hooks the Pause UI here.</summary>
        Paused = 3,

        /// <summary>Player crashed / run ended. PHASE 8 triggers this, PHASE 10 shows Game Over UI.</summary>
        GameOver = 4
    }

    /// <summary>Why a run ended. PHASE 8 (collision) will pass Crash; PHASE 10 may pass Manual (quit button).</summary>
    public enum RunEndReason
    {
        None = 0,
        Crash = 1,
        Manual = 2
    }
}
