// ============================================================================
//  GameConfig.cs
//  Location : Assets/_Project/Scripts/Core/GameConfig.cs
//  Phase    : 1
//
//  ScriptableObject holding global engine/loop settings. Create the asset via
//      Right-click in Project > Create > SliderRunner > Game Config
//  and drag it onto the GameManager's "Config" slot.
//
//  FUTURE PHASES: add their tunables here as new sections, e.g.
//     PHASE 3 : forwardSpeed, gravity        PHASE 4 : laneWidth, swipeThreshold
//     PHASE 5 : jumpHeight                   PHASE 6 : chunkLength, chunksAhead
//     PHASE 7 : spawn chances                PHASE 9 : speed ramp-up, coin value
// ============================================================================

using UnityEngine;

namespace SliderRunner.Core
{
    [CreateAssetMenu(fileName = "GameConfig", menuName = "SliderRunner/Game Config")]
    public sealed class GameConfig : ScriptableObject
    {
        [Header("Frame Rate & Timing")]
        [Tooltip("Target FPS. 60 is the standard for mobile runners.")]
        [Range(30, 120)] public int targetFrameRate = 60;

        [Tooltip("Disable VSync on mobile so targetFrameRate is honored.")]
        public bool vSync = false;

        [Tooltip("Physics step in seconds. 1/60 = 0.01667 keeps physics aligned with 60 FPS.")]
        [Range(0.005f, 0.04f)] public float fixedDeltaTime = 1f / 60f;

        [Tooltip("Max frame time Unity will simulate. Prevents huge physics jumps after a lag spike.")]
        [Range(0.05f, 0.5f)] public float maximumDeltaTime = 0.1f;

        [Header("Device Behaviour")]
        [Tooltip("Lock the screen to portrait (typical for 3-lane runners).")]
        public bool lockPortrait = true;

        [Tooltip("Stop the phone screen from dimming mid-run.")]
        public bool neverSleepScreen = true;

        [Header("Flow")]
        [Tooltip("If true, the run starts automatically after boot (skips the menu). Handy for testing.")]
        public bool autoStartRun = false;

        [Tooltip("Pause the game automatically when the app loses focus (phone call, home button).")]
        public bool pauseOnAppPause = true;

        /// <summary>Fallback used by GameManager when no asset is assigned.</summary>
        public static GameConfig CreateRuntimeDefault()
        {
            var cfg = CreateInstance<GameConfig>();
            cfg.name = "GameConfig (Runtime Default)";
            return cfg;
        }
    }
}
