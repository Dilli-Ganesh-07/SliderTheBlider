// ============================================================================
//  EventBus.cs
//  Location : Assets/_Project/Scripts/Core/EventBus.cs
//  Phase    : 1
//
//  Tiny, allocation-free, type-safe publish/subscribe.
//
//  Usage:
//      void OnEnable()  => EventBus<RunEndedEvent>.Subscribe(OnRunEnded);
//      void OnDisable() => EventBus<RunEndedEvent>.Unsubscribe(OnRunEnded);
//      EventBus<RunEndedEvent>.Raise(new RunEndedEvent(RunEndReason.Crash, 12.3f));
//
//  ALWAYS unsubscribe in OnDisable, otherwise destroyed objects keep receiving events.
//
//  Why a generic static class instead of a Dictionary<Type, List<Delegate>>?
//   - No boxing, no dictionary lookup, no casts.
//   - Each event type gets its own static field, resolved at JIT/IL2CPP time.
// ============================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

namespace SliderRunner.Core
{
    public static class EventBus<T> where T : struct
    {
        private static Action<T> _handlers;

        static EventBus()
        {
            // Register a "clear" callback so statics are wiped when entering Play Mode
            // with "Reload Domain" disabled (Project Settings > Editor > Enter Play Mode Settings).
            EventBusReset.Register(() => _handlers = null);
        }

        public static void Subscribe(Action<T> handler)   { _handlers += handler; }
        public static void Unsubscribe(Action<T> handler) { _handlers -= handler; }

        public static void Raise(T evt)
        {
            // Delegates are immutable, so subscribing/unsubscribing inside a handler is safe.
            _handlers?.Invoke(evt);
        }
    }

    /// <summary>Internal helper that clears every EventBus&lt;T&gt; at the start of each Play session.</summary>
    internal static class EventBusReset
    {
        private static readonly List<Action> _clearActions = new List<Action>();

        public static void Register(Action clear) { _clearActions.Add(clear); }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ClearAll()
        {
            for (int i = 0; i < _clearActions.Count; i++) _clearActions[i]?.Invoke();
        }
    }
}
