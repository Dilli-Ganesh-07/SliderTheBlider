// ============================================================================
//  GameEvents.cs
//  Location : Assets/_Project/Scripts/Core/GameEvents.cs
//  Phase    : 1
//
//  Plain readonly structs used as event payloads on EventBus<T>.
//  Structs => no garbage allocation when raised every run.
//
//  FUTURE PHASES add their own structs here (or in their own files), e.g.
//     PHASE 4 : LaneChangedEvent      PHASE 5 : JumpStartedEvent / LandedEvent
//     PHASE 8 : PlayerCrashedEvent    PHASE 9 : CoinCollectedEvent / ScoreChangedEvent
// ============================================================================

namespace SliderRunner.Core
{
    /// <summary>Raised after GameManager.State changes.</summary>
    public readonly struct GameStateChangedEvent
    {
        public readonly GameState Previous;
        public readonly GameState Current;

        public GameStateChangedEvent(GameState previous, GameState current)
        {
            Previous = previous;
            Current = current;
        }
    }

    /// <summary>Raised once, right after every system received OnRunStart().</summary>
    public readonly struct RunStartedEvent
    {
        public readonly int RunNumber; // 1 = first run this session

        public RunStartedEvent(int runNumber) { RunNumber = runNumber; }
    }

    /// <summary>Raised once, right after every system received OnRunEnd().</summary>
    public readonly struct RunEndedEvent
    {
        public readonly RunEndReason Reason;
        public readonly float RunDuration; // seconds of *Playing* time

        public RunEndedEvent(RunEndReason reason, float runDuration)
        {
            Reason = reason;
            RunDuration = runDuration;
        }
    }
}
