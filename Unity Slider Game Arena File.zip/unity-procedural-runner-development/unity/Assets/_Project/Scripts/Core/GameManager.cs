// ============================================================================
//  GameManager.cs
//  Location : Assets/_Project/Scripts/Core/GameManager.cs
//  Phase    : 1  -  Engine Initialization & Main Game Loop
//
//  RESPONSIBILITIES
//   1. Boot: apply engine settings (FPS, physics step, orientation, sleep).
//   2. Own the GameState machine (Boot > Menu > Playing > Paused > GameOver).
//   3. Own the MAIN LOOP: forward Update / FixedUpdate / LateUpdate to every
//      registered IGameSystem, but ONLY while State == Playing.
//   4. Broadcast run lifecycle (reset / start / end) to systems + EventBus.
//
//  There is exactly ONE GameManager in the scene. All other scripts reach it
//  through GameManager.Instance (or, better, by inheriting GameSystemBehaviour).
//
//  ----------------------------------------------------------------------------
//  HOW FUTURE PHASES PLUG IN  (search this file for "PHASE" to see each hook)
//  ----------------------------------------------------------------------------
//   Phase 2  Camera & Lighting ........ CameraRig : GameSystemBehaviour  -> LateTick()
//   Phase 3  Player Controller ........ PlayerController                 -> FixedTick()
//   Phase 4  Input & Lane switching ... InputService                     -> Tick()  (Order -100)
//   Phase 5  Jump & Stunts ............ PlayerJump                       -> FixedTick()
//   Phase 6  Track generator .......... TrackGenerator                   -> Tick()
//   Phase 7  Obstacles & Pooling ...... ObstacleSpawner                  -> Tick()
//   Phase 8  Collisions & Crash ....... CrashHandler -> GameManager.EndRun(RunEndReason.Crash)
//   Phase 9  Coins & Progression ...... ScoreSystem                      -> Tick() / OnRunReset()
//   Phase 10 UI ....................... UIController listens to EventBus<GameStateChangedEvent>
// ============================================================================

using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace SliderRunner.Core
{
    [DefaultExecutionOrder(-100)] // Awake/OnEnable of GameManager runs before every other script.
    [DisallowMultipleComponent]
    public sealed class GameManager : MonoBehaviour
    {
        // ------------------------------------------------------------------
        //  Singleton
        // ------------------------------------------------------------------
        public static GameManager Instance { get; private set; }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics() { Instance = null; }

        // ------------------------------------------------------------------
        //  Inspector
        // ------------------------------------------------------------------
        [Header("Configuration")]
        [SerializeField] private GameConfig config;

        // ------------------------------------------------------------------
        //  Public read-only state
        // ------------------------------------------------------------------
        public GameConfig Config => config;
        public GameState State { get; private set; } = GameState.Boot;

        /// <summary>Seconds spent in the Playing state during the current run.</summary>
        public float RunTime { get; private set; }

        /// <summary>How many runs have been started this session (1-based).</summary>
        public int RunCount { get; private set; }

        public bool IsPlaying => State == GameState.Playing;

        // ------------------------------------------------------------------
        //  System registry (the "hook list")
        // ------------------------------------------------------------------
        private readonly List<IGameSystem> _systems = new List<IGameSystem>();
        private IGameSystem[] _snapshot = System.Array.Empty<IGameSystem>();
        private bool _snapshotDirty;

        // ==================================================================
        //  UNITY LIFECYCLE
        // ==================================================================
        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning("[GameManager] Duplicate instance destroyed.");
                Destroy(gameObject);
                return;
            }
            Instance = this;

            if (config == null)
            {
                Debug.LogWarning("[GameManager] No GameConfig assigned - using runtime defaults.");
                config = GameConfig.CreateRuntimeDefault();
            }

            ApplyEngineSettings();
        }

        private void Start()
        {
            StartCoroutine(BootRoutine());
        }

        private IEnumerator BootRoutine()
        {
            // Wait one frame so every other script has finished Awake/OnEnable/Start
            // and registered itself before the first state change is broadcast.
            yield return null;

            SetState(GameState.Menu);

            if (config.autoStartRun)
                StartRun();
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
                Time.timeScale = 1f; // never leave the editor paused
            }
        }

        private void OnApplicationPause(bool paused)
        {
            // Mobile: phone call, home button, notification shade...
            if (paused && config != null && config.pauseOnAppPause && State == GameState.Playing)
                PauseRun();
        }

        // ==================================================================
        //  MAIN LOOP  -  forwards to systems ONLY while Playing
        // ==================================================================
        private void Update()
        {
            RefreshSnapshotIfNeeded();
            if (State != GameState.Playing) return;

            float dt = Time.deltaTime;
            RunTime += dt;

            // PHASE 4 : InputService.Tick reads touches/swipes here (Order -100, runs first).
            // PHASE 3/5: Player logic that is not physics-based.
            // PHASE 6/7: TrackGenerator + ObstacleSpawner recycle chunks/objects based on player Z.
            // PHASE 9 : ScoreSystem adds distance score every frame.
            var systems = _snapshot;
            for (int i = 0; i < systems.Length; i++)
            {
                if (State != GameState.Playing) break; // a system may have ended the run
                if (IsDead(systems[i])) continue;
                systems[i].Tick(dt);
            }
        }

        private void FixedUpdate()
        {
            if (State != GameState.Playing) return;

            float fdt = Time.fixedDeltaTime;

            // PHASE 3 : PlayerController applies constant forward motion + gravity here.
            // PHASE 4 : Lane switching moves the player toward the target lane X here.
            // PHASE 5 : Jump impulse / aerial rotation integrate here.
            var systems = _snapshot;
            for (int i = 0; i < systems.Length; i++)
            {
                if (State != GameState.Playing) break;
                if (IsDead(systems[i])) continue;
                systems[i].FixedTick(fdt);
            }
        }

        private void LateUpdate()
        {
            if (State != GameState.Playing) return;

            float dt = Time.deltaTime;

            // PHASE 2 : CameraRig follows the player here (after the player has moved this frame).
            var systems = _snapshot;
            for (int i = 0; i < systems.Length; i++)
            {
                if (State != GameState.Playing) break;
                if (IsDead(systems[i])) continue;
                systems[i].LateTick(dt);
            }
        }

        // ==================================================================
        //  PUBLIC API  -  run flow
        // ==================================================================

        /// <summary>Menu -> Playing. Called by the Play button (PHASE 10) or autoStartRun.</summary>
        public void StartRun()
        {
            if (State != GameState.Menu)
            {
                Debug.LogWarning($"[GameManager] StartRun ignored in state {State}. Use Restart().");
                return;
            }
            BeginRun();
        }

        /// <summary>Playing / Paused / GameOver -> fresh Playing run. Called by "Retry" (PHASE 10).</summary>
        public void Restart()
        {
            if (State == GameState.Boot || State == GameState.Menu)
            {
                Debug.LogWarning($"[GameManager] Restart ignored in state {State}. Use StartRun().");
                return;
            }
            BeginRun();
        }

        /// <summary>Playing -> Paused (freezes physics and Time.deltaTime-based logic).</summary>
        public void PauseRun()
        {
            if (State != GameState.Playing) return;
            Time.timeScale = 0f;
            SetState(GameState.Paused);
            // PHASE 10: Pause panel shows itself by listening to GameStateChangedEvent.
        }

        /// <summary>Paused -> Playing.</summary>
        public void ResumeRun()
        {
            if (State != GameState.Paused) return;
            Time.timeScale = 1f;
            SetState(GameState.Playing);
        }

        /// <summary>
        /// Playing -> GameOver. Single entry point for every way a run can end.
        /// PHASE 8 calls this with RunEndReason.Crash from the collision handler.
        /// </summary>
        public void EndRun(RunEndReason reason)
        {
            if (State != GameState.Playing) return; // guards against double crash events

            SetState(GameState.GameOver);

            // PHASE 8 : play crash animation / stop player. 
            // PHASE 9 : ScoreSystem saves high score here.
            var systems = _snapshot;
            for (int i = 0; i < systems.Length; i++)
            {
                if (IsDead(systems[i])) continue;
                systems[i].OnRunEnd();
            }

            // PHASE 10: GameOver UI listens to this event to show final score & Retry button.
            EventBus<RunEndedEvent>.Raise(new RunEndedEvent(reason, RunTime));
        }

        /// <summary>Any state -> Menu with everything reset.</summary>
        public void ReturnToMenu()
        {
            if (State == GameState.Boot) return;

            Time.timeScale = 1f;
            BroadcastReset();
            RunTime = 0f;
            SetState(GameState.Menu);
        }

        // ==================================================================
        //  PUBLIC API  -  system registration
        // ==================================================================
        public void Register(IGameSystem system)
        {
            if (system == null || _systems.Contains(system)) return;
            _systems.Add(system);
            _snapshotDirty = true;
        }

        public void Unregister(IGameSystem system)
        {
            if (system == null) return;
            if (_systems.Remove(system))
                _snapshotDirty = true;
        }

        // ==================================================================
        //  INTERNALS
        // ==================================================================
        private void BeginRun()
        {
            Time.timeScale = 1f;
            RefreshSnapshotIfNeeded();

            // 1) Wipe all per-run state (PHASE 6: destroy chunks, PHASE 7: return objects to pool,
            //    PHASE 9: zero score & coins, PHASE 3: teleport player to start).
            BroadcastReset();

            RunTime = 0f;
            RunCount++;

            // 2) Flip state BEFORE OnRunStart so systems can rely on IsPlaying == true.
            SetState(GameState.Playing);

            // 3) Tell systems the run started (PHASE 6: pre-spawn first chunks, PHASE 3: unfreeze player).
            var systems = _snapshot;
            for (int i = 0; i < systems.Length; i++)
            {
                if (IsDead(systems[i])) continue;
                systems[i].OnRunStart();
            }

            EventBus<RunStartedEvent>.Raise(new RunStartedEvent(RunCount));
        }

        private void BroadcastReset()
        {
            RefreshSnapshotIfNeeded();
            var systems = _snapshot;
            for (int i = 0; i < systems.Length; i++)
            {
                if (IsDead(systems[i])) continue;
                systems[i].OnRunReset();
            }
        }

        private void SetState(GameState next)
        {
            if (State == next) return;

            GameState prev = State;
            State = next;

            // PHASE 10: UI panels (Menu / HUD / Pause / GameOver) subscribe to this event.
            EventBus<GameStateChangedEvent>.Raise(new GameStateChangedEvent(prev, next));
        }

        private void RefreshSnapshotIfNeeded()
        {
            if (!_snapshotDirty) return;

            // Linq OrderBy is stable: systems with equal Order keep registration order.
            // Runs only when something (un)registers, so the allocation is negligible.
            _snapshot = _systems.OrderBy(s => s.Order).ToArray();
            _snapshotDirty = false;
        }

        /// <summary>True if the system is a destroyed UnityEngine.Object (Unity's fake-null).</summary>
        private static bool IsDead(IGameSystem system)
        {
            return system is UnityEngine.Object obj && obj == null;
        }

        private void ApplyEngineSettings()
        {
            // On Android/iOS, targetFrameRate is only honored when vSyncCount == 0.
            QualitySettings.vSyncCount = config.vSync ? 1 : 0;
            Application.targetFrameRate = config.targetFrameRate;

            Time.fixedDeltaTime = config.fixedDeltaTime;
            Time.maximumDeltaTime = config.maximumDeltaTime;
            Time.timeScale = 1f;

            Screen.sleepTimeout = config.neverSleepScreen ? SleepTimeout.NeverSleep : SleepTimeout.SystemSetting;

            if (config.lockPortrait)
                Screen.orientation = ScreenOrientation.Portrait;
        }
    }
}
