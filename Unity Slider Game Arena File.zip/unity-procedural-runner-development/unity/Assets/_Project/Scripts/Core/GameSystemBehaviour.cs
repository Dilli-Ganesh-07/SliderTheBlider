// ============================================================================
//  GameSystemBehaviour.cs
//  Location : Assets/_Project/Scripts/Core/GameSystemBehaviour.cs
//  Phase    : 1
//
//  Convenience base class. Inherit from this instead of MonoBehaviour and you
//  get automatic register/unregister with GameManager plus empty virtual hooks
//  you can override only when needed.
//
//  Example (Phase 3):
//      public class PlayerController : GameSystemBehaviour
//      {
//          public override int Order => 0;
//          public override void FixedTick(float dt) { /* move forward */ }
//      }
//
//  If you need your own OnEnable/OnDisable, override them and call base.OnEnable().
// ============================================================================

using UnityEngine;

namespace SliderRunner.Core
{
    public abstract class GameSystemBehaviour : MonoBehaviour, IGameSystem
    {
        private bool _registered;

        public virtual int Order => 0;

        public virtual void OnRunReset() { }
        public virtual void OnRunStart() { }
        public virtual void Tick(float deltaTime) { }
        public virtual void FixedTick(float fixedDeltaTime) { }
        public virtual void LateTick(float deltaTime) { }
        public virtual void OnRunEnd() { }

        protected virtual void OnEnable()
        {
            TryRegister();
        }

        protected virtual void Start()
        {
            // Fallback in case GameManager's Awake had not run yet during OnEnable.
            TryRegister();
        }

        protected virtual void OnDisable()
        {
            if (_registered && GameManager.Instance != null)
                GameManager.Instance.Unregister(this);
            _registered = false;
        }

        private void TryRegister()
        {
            if (_registered) return;

            if (GameManager.Instance == null)
                return; // will retry in Start()

            GameManager.Instance.Register(this);
            _registered = true;
        }
    }
}
