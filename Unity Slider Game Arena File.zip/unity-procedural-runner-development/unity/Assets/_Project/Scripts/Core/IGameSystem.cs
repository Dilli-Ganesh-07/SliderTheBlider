// ============================================================================
//  IGameSystem.cs
//  Location : Assets/_Project/Scripts/Core/IGameSystem.cs
//  Phase    : 1
//
//  THE HOOK CONTRACT.
//  Any script that wants to take part in the main loop implements this
//  interface (usually by inheriting GameSystemBehaviour) and registers itself
//  with GameManager. GameManager then calls it at the right moments.
//
//  Call order inside one frame (only while State == Playing):
//      Tick()  ->  (Unity physics)  ->  FixedTick() [0..n times]  ->  LateTick()
//  Systems are sorted by Order (lowest first) inside each callback.
// ============================================================================

namespace SliderRunner.Core
{
    public interface IGameSystem
    {
        /// <summary>
        /// Lower runs first. Suggested bands used by this project:
        ///   -100 Input (Phase 4)     0 Player (Phases 3,5)    100 World/Track (Phases 6,7)
        ///    200 Collisions (Phase 8) 300 Score/Coins (Phase 9) 900 Camera (Phase 2)  1000 UI/Debug (Phase 10)
        /// </summary>
        int Order { get; }

        /// <summary>Run is about to be (re)started from a clean slate. Reset all per-run state here.</summary>
        void OnRunReset();

        /// <summary>The run has begun (State is now Playing).</summary>
        void OnRunStart();

        /// <summary>Per-frame logic. Called from GameManager.Update while Playing.</summary>
        void Tick(float deltaTime);

        /// <summary>Physics-step logic. Called from GameManager.FixedUpdate while Playing.</summary>
        void FixedTick(float fixedDeltaTime);

        /// <summary>After-everything logic (cameras). Called from GameManager.LateUpdate while Playing.</summary>
        void LateTick(float deltaTime);

        /// <summary>The run has ended (State is now GameOver).</summary>
        void OnRunEnd();
    }
}
